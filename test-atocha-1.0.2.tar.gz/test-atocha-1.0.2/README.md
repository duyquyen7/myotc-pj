
## Mac os
> brew install coreutils

## Make chain spec file
> ./target/debug/appchain-atocha build-spec --disable-default-bootnode --chain dev > atochaSpec.json
> sha256sum atochaSpec.json > SHA256SUMS



